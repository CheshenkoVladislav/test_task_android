package com.example.vlad.alphatest.interfaceses.model;

import android.os.Bundle;

import com.example.vlad.alphatest.data.Image;

import java.util.List;

public interface MvpModel {
    void init();
}
