package com.example.vlad.alphatest.repository;

public interface Repository {

}
