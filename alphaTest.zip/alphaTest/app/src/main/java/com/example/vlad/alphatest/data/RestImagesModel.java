package com.example.vlad.alphatest.data;

import java.util.List;

public class RestImagesModel {
    private List<RestImageModel> response;

    public List<RestImageModel> getResponse() {
        return response;
    }

    public void setResponse(List<RestImageModel> response) {
        this.response = response;
    }
}
