package com.example.vlad.alphatest.repository;

import com.example.vlad.alphatest.threads.SubscriberManager;

public abstract class BaseRepository extends SubscriberManager {
}
