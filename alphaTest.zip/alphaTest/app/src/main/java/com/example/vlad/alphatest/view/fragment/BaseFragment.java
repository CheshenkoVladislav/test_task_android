package com.example.vlad.alphatest.view.fragment;

import android.support.v4.app.Fragment;

public abstract class BaseFragment extends Fragment {

}
