package com.example.vlad.alphatest.data;

public class Params {
}
