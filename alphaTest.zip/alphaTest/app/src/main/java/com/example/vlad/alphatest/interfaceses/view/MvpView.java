package com.example.vlad.alphatest.interfaceses.view;

public interface MvpView {
}
