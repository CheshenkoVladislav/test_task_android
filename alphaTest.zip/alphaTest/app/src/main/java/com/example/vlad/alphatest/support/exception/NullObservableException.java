package com.example.vlad.alphatest.support.exception;

public class NullObservableException extends NullPointerException {
}
