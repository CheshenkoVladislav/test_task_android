package com.example.vlad.alphatest.interfaceses.listeners;

import android.graphics.drawable.Drawable;

public interface OnImageClickListener {
    void onImageClick(Drawable imageDrawable);
}
