package com.example.vlad.alphatest.data;

import java.util.List;

public class DBImagesModel {
    private Image images;

    public DBImagesModel() {
    }

    public Image getImages() {
        return images;
    }

    public void setImages(Image images) {
        this.images = images;
    }
}
